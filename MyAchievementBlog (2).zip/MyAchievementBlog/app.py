from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

notes = {
    "Мой первый шаг": "Сегодня я начала изучать Flask и Jinja2.",
    "Новые возможности": "Узнала, как работают маршруты и шаблоны."
}


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/notes", methods=["GET", "POST"])
def diary():
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        content = request.form.get("content", "").strip()

        if title and content:
            notes[title] = content

        return redirect(url_for("diary"))

    return render_template("notes.html", notes=notes)


if __name__ == "__main__":
    app.run(debug=True)